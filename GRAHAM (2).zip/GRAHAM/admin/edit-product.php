<?php
include '../config/database.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: products.php");
    exit();
}
$product_id = (int)$_GET['id'];
$message = "";

$productQuery = $conn->prepare("SELECT products.*, inventory.stock
    FROM products LEFT JOIN inventory ON products.product_id = inventory.product_id
    WHERE products.product_id = ?");
$productQuery->bind_param("i", $product_id);
$productQuery->execute();
$product = $productQuery->get_result()->fetch_assoc();
if (!$product) die("Product not found.");

if (isset($_POST['update'])) {
    $name = trim($_POST['product_name'] ?? '');
    $category = (int)($_POST['category'] ?? 0);
    $price = (float)($_POST['price'] ?? 0); // Legacy/default price for existing pages
    $stock = (int)($_POST['stock'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'Available';
    $featured = isset($_POST['featured']) ? 1 : 0;
    $image = $_POST['old_image'] ?? '';

    $sizeNames = $_POST['size_name'] ?? [];
    $sizePrices = $_POST['size_price'] ?? [];
    $sizes = [];
    foreach ($sizeNames as $i => $rawName) {
        $sizeName = trim($rawName);
        $rawPrice = $sizePrices[$i] ?? '';
        if ($sizeName === '' && $rawPrice === '') continue;
        if ($sizeName === '' || $rawPrice === '' || !is_numeric($rawPrice) || (float)$rawPrice < 0) {
            $message = "<div class='alert alert-danger'>Please enter both a size and a valid non-negative price for every size row.</div>";
            break;
        }
        if (!in_array($sizeName, ['Small','Medium','Large'], true)) {
            $message = "<div class='alert alert-danger'>Size names must be Small, Medium, or Large to match the customer order options.</div>";
            break;
        }
        foreach ($sizes as $savedSize) {
            if ($savedSize['name'] === $sizeName) {
                $message = "<div class='alert alert-danger'>Each size can only be entered once.</div>";
                break 2;
            }
        }
        $sizes[] = ['name' => $sizeName, 'price' => (float)$rawPrice];
    }
    if ($message === '' && $name === '') $message = "<div class='alert alert-danger'>Product name is required.</div>";

    if ($message === '' && isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image = time() . "_" . basename($_FILES['image']['name']);
        if (!move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/products/" . $image)) {
            $message = "<div class='alert alert-danger'>Unable to upload product image.</div>";
        }
    }

    if ($message === '') {
        $conn->begin_transaction();
        try {
            $update = $conn->prepare("UPDATE products SET category_id=?, product_name=?, description=?, price=?, image=?, status=?, featured=? WHERE product_id=?");
            if (!$update) throw new Exception($conn->error);
            $update->bind_param("issdssii", $category, $name, $description, $price, $image, $status, $featured, $product_id);
            if (!$update->execute()) throw new Exception($update->error);
            $update->close();

            $stockCheck = $conn->prepare("SELECT product_id FROM inventory WHERE product_id=?");
            $stockCheck->bind_param("i", $product_id);
            $stockCheck->execute();
            $stockExists = $stockCheck->get_result()->num_rows > 0;
            $stockCheck->close();
            if ($stockExists) {
                $stockUpdate = $conn->prepare("UPDATE inventory SET stock=? WHERE product_id=?");
                $stockUpdate->bind_param("ii", $stock, $product_id);
            } else {
                $stockUpdate = $conn->prepare("INSERT INTO inventory(stock, product_id) VALUES (?, ?)");
                $stockUpdate->bind_param("ii", $stock, $product_id);
            }
            if (!$stockUpdate->execute()) throw new Exception($stockUpdate->error);
            $stockUpdate->close();

            $deleteSizes = $conn->prepare("DELETE FROM product_sizes WHERE product_id=?");
            if (!$deleteSizes) throw new Exception($conn->error);
            $deleteSizes->bind_param("i", $product_id);
            if (!$deleteSizes->execute()) throw new Exception($deleteSizes->error);
            $deleteSizes->close();

            if (count($sizes) > 0) {
                $sizeStmt = $conn->prepare("INSERT INTO product_sizes (product_id, size_name, price) VALUES (?, ?, ?)");
                if (!$sizeStmt) throw new Exception($conn->error);
                foreach ($sizes as $size) {
                    $sizeStmt->bind_param("isd", $product_id, $size['name'], $size['price']);
                    if (!$sizeStmt->execute()) throw new Exception($sizeStmt->error);
                }
                $sizeStmt->close();
            }
            $conn->commit();
            $message = "<div class='alert alert-success'><i class='bi bi-check-circle-fill'></i> Product and size prices updated successfully.</div>";
        } catch (Exception $e) {
            $conn->rollback();
            $message = "<div class='alert alert-danger'>Unable to update product: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }
    // Reload saved values after update so the form reflects the database.
    $productQuery->execute();
    $product = $productQuery->get_result()->fetch_assoc();
}

$sizeQuery = $conn->prepare("SELECT size_name, price FROM product_sizes WHERE product_id=? ORDER BY product_size_id ASC");
$sizeQuery->bind_param("i", $product_id);
$sizeQuery->execute();
$savedSizes = $sizeQuery->get_result()->fetch_all(MYSQLI_ASSOC);
$categories = $conn->query("SELECT * FROM categories ORDER BY category_name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Product | Graham Delight</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*{font-family:'Poppins',sans-serif}body{background:#f5f5f5}
.sidebar{position:fixed;left:0;top:0;width:250px;height:100vh;background:#6F4E37}
.sidebar h3{padding:20px;text-align:center;color:white}.sidebar a{display:block;padding:15px 25px;color:white;text-decoration:none}
.sidebar a:hover,.sidebar a.active{background:#D4AF37}.main{margin-left:250px;padding:30px}
.card{border:none;border-radius:15px}.preview{width:220px;height:220px;border-radius:15px;overflow:hidden;border:2px solid #ddd}
.preview img{width:100%;height:100%;object-fit:cover}.btn-save{background:#198754;color:white;font-weight:bold}
.btn-save:hover{background:#157347;color:white}.size-row{background:#f8f9fa;border:1px solid #e9ecef;border-radius:10px;padding:12px;margin-bottom:10px}
@media(max-width:768px){.sidebar{position:relative;width:100%;height:auto}.main{margin-left:0;padding:16px}}
</style>
</head>
<body>
<div class="sidebar">
<h3>🍰 Graham Delight</h3>
<a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
<a href="products.php" class="active"><i class="bi bi-box-seam"></i> Products</a>
<a href="orders.php"><i class="bi bi-cart"></i> Orders</a>
<a href="customers.php"><i class="bi bi-people"></i> Customers</a>
<a href="inventory.php"><i class="bi bi-boxes"></i> Inventory</a>
<a href="reports.php"><i class="bi bi-bar-chart"></i> Reports</a>
<a href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>
<div class="main">
<h2 class="mb-4">Edit Product</h2>
<div class="card shadow"><div class="card-body">
<?php if($message !== '') echo $message; ?>
<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="old_image" value="<?php echo htmlspecialchars($product['image'] ?? ''); ?>">
<div class="row">
<div class="col-md-8">
<div class="mb-3"><label class="form-label">Product Name</label>
<input type="text" name="product_name" class="form-control" required value="<?php echo htmlspecialchars($product['product_name']); ?>"></div>
<div class="row">
<div class="col-md-6 mb-3"><label class="form-label">Category</label>
<select name="category" class="form-select" required>
<?php while($cat = $categories->fetch_assoc()){ ?>
<option value="<?php echo (int)$cat['category_id']; ?>" <?php if($cat['category_id']==$product['category_id']) echo "selected"; ?>><?php echo htmlspecialchars($cat['category_name']); ?></option>
<?php } ?>
</select></div>
<div class="col-md-6 mb-3"><label class="form-label">Default / Base Price (₱)</label>
<input type="number" step="0.01" min="0" name="price" class="form-control" required value="<?php echo htmlspecialchars($product['price']); ?>">
<div class="form-text">Kept for compatibility with existing pages. Set each actual size price below.</div></div>
</div>
<div class="mb-3"><label class="form-label">Stock Quantity</label>
<input type="number" min="0" name="stock" class="form-control" required value="<?php echo htmlspecialchars($product['stock'] ?? 0); ?>"></div>

<div class="mb-4">
<div class="d-flex justify-content-between align-items-center mb-2">
<div><h5 class="mb-0">Product Sizes & Prices</h5><small class="text-muted">Edit a size's name or price, add new sizes, or remove sizes.</small></div>
<button type="button" class="btn btn-outline-primary btn-sm" id="addSize"><i class="bi bi-plus-circle"></i> Add Size</button>
</div>
<div id="sizeRows">
<?php if(count($savedSizes) > 0){ foreach($savedSizes as $size){ ?>
<div class="row size-row align-items-end">
<div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Size</label><input type="text" name="size_name[]" class="form-control" required value="<?php echo htmlspecialchars($size['size_name']); ?>"></div>
<div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Price (₱)</label><input type="number" name="size_price[]" class="form-control" min="0" step="0.01" required value="<?php echo htmlspecialchars($size['price']); ?>"></div>
<div class="col-md-2"><button type="button" class="btn btn-outline-danger w-100 remove-size"><i class="bi bi-trash"></i> Remove</button></div>
</div>
<?php }} else { ?>
<div class="row size-row align-items-end">
<div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Size</label><input type="text" name="size_name[]" class="form-control" placeholder="e.g. Small / 8 oz"></div>
<div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Price (₱)</label><input type="number" name="size_price[]" class="form-control" min="0" step="0.01" placeholder="e.g. 99.00"></div>
<div class="col-md-2"><button type="button" class="btn btn-outline-danger w-100 remove-size"><i class="bi bi-trash"></i> Remove</button></div>
</div>
<?php } ?>
</div>
</div>

<div class="mb-3"><label class="form-label">Description</label>
<textarea name="description" rows="4" class="form-control"><?php echo htmlspecialchars($product['description']); ?></textarea></div>
<div class="mb-3"><label class="form-label">Status</label>
<select name="status" class="form-select">
<option value="Available" <?php if($product['status']=="Available") echo "selected"; ?>>Available</option>
<option value="Out of Stock" <?php if($product['status']=="Out of Stock") echo "selected"; ?>>Out of Stock</option>
<option value="Inactive" <?php if($product['status']=="Inactive") echo "selected"; ?>>Inactive</option>
</select></div>
<div class="form-check form-switch mb-3"><input type="checkbox" class="form-check-input" name="featured" id="featured" <?php if($product['featured']==1) echo "checked"; ?>>
<label class="form-check-label" for="featured">Featured Product</label></div>
</div>

<div class="col-md-4">
<label class="form-label">Current Image</label><div class="preview mb-3">
<?php $image="../uploads/products/".$product['image']; if(!empty($product['image']) && file_exists($image)){ ?>
<img id="previewImage" src="<?php echo htmlspecialchars($image); ?>">
<?php } else { ?><img id="previewImage" src="../assets/images/image.png"><?php } ?>
</div>
<input type="file" id="imageInput" name="image" class="form-control">
</div>
<div class="col-12 mt-4">
<button type="submit" name="update" class="btn btn-save"><i class="bi bi-check-circle"></i> Update Product</button>
<a href="products.php" class="btn btn-secondary">Cancel</a>
</div>
</div>
</form>
</div></div>
</div>
<script>
const sizeRows=document.getElementById('sizeRows');
document.getElementById('addSize').addEventListener('click',()=>{
 const row=document.createElement('div');row.className='row size-row align-items-end';
 row.innerHTML=`<div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Size</label><input type="text" name="size_name[]" class="form-control" placeholder="e.g. Large / 16 oz" required></div><div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Price (₱)</label><input type="number" name="size_price[]" class="form-control" min="0" step="0.01" placeholder="e.g. 159.00" required></div><div class="col-md-2"><button type="button" class="btn btn-outline-danger w-100 remove-size"><i class="bi bi-trash"></i> Remove</button></div>`;
 sizeRows.appendChild(row);
});
sizeRows.addEventListener('click',e=>{const btn=e.target.closest('.remove-size');if(btn&&sizeRows.querySelectorAll('.size-row').length>1)btn.closest('.size-row').remove();});
document.getElementById("imageInput").addEventListener("change",function(){
 if(this.files&&this.files[0]){const reader=new FileReader();reader.onload=e=>document.getElementById("previewImage").src=e.target.result;reader.readAsDataURL(this.files[0]);}
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
