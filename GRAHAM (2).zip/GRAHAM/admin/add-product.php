<?php
include_once '../config/database.php';

if (!isset($conn)) {
    die("Database connection failed. Check config/database.php");
}

$message = "";

if (isset($_POST['save'])) {
    $name = trim($_POST['product_name'] ?? '');
    $category = (int)($_POST['category'] ?? 0);
    $price = (float)($_POST['price'] ?? 0); // Legacy/default price for existing pages
    $stock = (int)($_POST['stock'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'Available';
    $featured = isset($_POST['featured']) ? 1 : 0;

    $sizeNames = $_POST['size_name'] ?? [];
    $sizePrices = $_POST['size_price'] ?? [];
    $sizes = [];
    foreach ($sizeNames as $i => $rawName) {
        $sizeName = trim($rawName);
        $rawPrice = $sizePrices[$i] ?? '';
        if ($sizeName === '' && $rawPrice === '') continue;
        if ($sizeName === '' || $rawPrice === '' || !is_numeric($rawPrice) || (float)$rawPrice < 0) {
            $message = "<div class='alert alert-danger'>Please enter both a size and a valid non-negative price for every size row.</div>";
            break;
        }
        $sizes[] = ['name' => $sizeName, 'price' => (float)$rawPrice];
    }

    if ($message === '' && $name === '') {
        $message = "<div class='alert alert-danger'>Product name is required.</div>";
    }

    $image = "";
    if ($message === '' && isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image = time() . "_" . basename($_FILES['image']['name']);
        $target = "../uploads/products/" . $image;
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $message = "<div class='alert alert-danger'>Unable to upload product image.</div>";
        }
    }

    if ($message === '') {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO products
                (category_id, product_name, description, price, image, status, featured)
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            if (!$stmt) throw new Exception($conn->error);
            $stmt->bind_param("issdssi", $category, $name, $description, $price, $image, $status, $featured);
            if (!$stmt->execute()) throw new Exception($stmt->error);
            $product_id = $conn->insert_id;
            $stmt->close();

            $inventory = $conn->prepare("INSERT INTO inventory(product_id, stock) VALUES (?, ?)");
            if (!$inventory) throw new Exception($conn->error);
            $inventory->bind_param("ii", $product_id, $stock);
            if (!$inventory->execute()) throw new Exception($inventory->error);
            $inventory->close();

            if (count($sizes) > 0) {
                $sizeStmt = $conn->prepare("INSERT INTO product_sizes (product_id, size_name, price) VALUES (?, ?, ?)");
                if (!$sizeStmt) throw new Exception($conn->error);
                foreach ($sizes as $size) {
                    $sizeStmt->bind_param("isd", $product_id, $size['name'], $size['price']);
                    if (!$sizeStmt->execute()) throw new Exception($sizeStmt->error);
                }
                $sizeStmt->close();
            }

            $conn->commit();
            $message = "<div class='alert alert-success'>Product added successfully, including its size prices.</div>";
        } catch (Exception $e) {
            $conn->rollback();
            $message = "<div class='alert alert-danger'>Unable to save product: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Product | Graham Delight</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*{font-family:'Poppins',sans-serif}
body{background:#f5f5f5}
.sidebar{position:fixed;top:0;left:0;width:250px;height:100vh;background:#6F4E37}
.sidebar h3{color:#fff;text-align:center;padding:20px;font-weight:bold}
.sidebar a{display:block;padding:15px 25px;color:#fff;text-decoration:none;transition:.3s}
.sidebar a:hover,.sidebar a.active{background:#D4AF37}
.main{margin-left:250px;padding:30px}
.card{border:none;border-radius:15px}
.btn-save{background:#198754;color:white;font-weight:bold}
.btn-save:hover{background:#157347;color:white}
.btn-cancel{background:#6c757d;color:white;font-weight:bold}
.preview{width:200px;height:200px;border:2px dashed #ccc;display:flex;justify-content:center;align-items:center;overflow:hidden;border-radius:10px;margin-top:10px}
.preview img{width:100%;height:100%;object-fit:cover;display:none}
.size-row{background:#f8f9fa;border:1px solid #e9ecef;border-radius:10px;padding:12px;margin-bottom:10px}
@media(max-width:768px){.sidebar{position:relative;width:100%;height:auto}.main{margin-left:0;padding:16px}}
</style>
</head>
<body>
<div class="sidebar">
<h3>🍰 Graham Delight</h3>
<a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
<a href="products.php" class="active"><i class="bi bi-box-seam"></i> Products</a>
<a href="orders.php"><i class="bi bi-cart"></i> Orders</a>
<a href="customers.php"><i class="bi bi-people"></i> Customers</a>
<a href="inventory.php"><i class="bi bi-boxes"></i> Inventory</a>
<a href="reports.php"><i class="bi bi-bar-chart"></i> Sales Report</a>
<a href="../index.html"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>

<div class="main">
<h2 class="mb-4">Add New Product</h2>
<div class="card shadow"><div class="card-body">
<?php if($message !== '') echo $message; ?>
<form method="POST" enctype="multipart/form-data">
<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Product Name</label>
<input type="text" name="product_name" class="form-control" required>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Category</label>
<select name="category" class="form-select" required>
<option value="1">Fruit</option><option value="2">Coffee</option><option value="3">Chocolate</option><option value="4">Special</option>
</select>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Default / Base Price (₱)</label>
<input type="number" step="0.01" min="0" name="price" class="form-control" value="0" required>
<div class="form-text">Kept for compatibility with existing pages. Set each actual size price below.</div>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Stock Quantity</label>
<input type="number" min="0" name="stock" class="form-control" value="0">
</div>

<div class="col-12 mb-4">
<div class="d-flex justify-content-between align-items-center mb-2">
<div><h5 class="mb-0">Product Sizes & Prices</h5><small class="text-muted">Add as many sizes as this product offers. Each size has its own editable price.</small></div>
<button type="button" class="btn btn-outline-primary btn-sm" id="addSize"><i class="bi bi-plus-circle"></i> Add Size</button>
</div>
<div id="sizeRows">
<div class="row size-row align-items-end">
<div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Size</label><input type="text" name="size_name[]" class="form-control" placeholder="e.g. Small / 8 oz"></div>
<div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Price (₱)</label><input type="number" name="size_price[]" class="form-control" min="0" step="0.01" placeholder="e.g. 99.00"></div>
<div class="col-md-2"><button type="button" class="btn btn-outline-danger w-100 remove-size" aria-label="Remove size"><i class="bi bi-trash"></i> Remove</button></div>
</div>
</div>
</div>

<div class="col-12 mb-3">
<label class="form-label">Description</label>
<textarea name="description" class="form-control" rows="3"></textarea>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Upload Product Image</label>
<input type="file" id="imageInput" name="image" class="form-control">
<div class="preview"><img id="previewImage"><span id="placeholderText">Image Preview</span></div>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Product Status</label>
<select name="status" class="form-select">
<option value="Available">Available</option><option value="Out of Stock">Out of Stock</option><option value="Inactive">Inactive</option>
</select>
<div class="form-check form-switch mt-4">
<input type="checkbox" name="featured" class="form-check-input" id="featured">
<label class="form-check-label" for="featured">Featured Product</label>
</div>
</div>
<div class="col-12 mt-3">
<button type="submit" name="save" class="btn btn-save">Save Product</button>
<a href="products.php" class="btn btn-cancel">Cancel</a>
</div>
</div>
</form>
</div></div>
</div>
<script>
const sizeRows = document.getElementById('sizeRows');
document.getElementById('addSize').addEventListener('click', () => {
 const row = document.createElement('div');
 row.className = 'row size-row align-items-end';
 row.innerHTML = `<div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Size</label><input type="text" name="size_name[]" class="form-control" placeholder="e.g. Medium / 12 oz"></div><div class="col-md-5 mb-2 mb-md-0"><label class="form-label">Price (₱)</label><input type="number" name="size_price[]" class="form-control" min="0" step="0.01" placeholder="e.g. 129.00"></div><div class="col-md-2"><button type="button" class="btn btn-outline-danger w-100 remove-size"><i class="bi bi-trash"></i> Remove</button></div>`;
 sizeRows.appendChild(row);
});
sizeRows.addEventListener('click', e => {
 const btn = e.target.closest('.remove-size');
 if (btn && sizeRows.querySelectorAll('.size-row').length > 1) btn.closest('.size-row').remove();
});
const imageInput=document.getElementById("imageInput"), preview=document.getElementById("previewImage"), placeholder=document.getElementById("placeholderText");
imageInput.addEventListener("change",function(){
 const file=this.files[0]; if(!file)return;
 const reader=new FileReader();
 reader.onload=e=>{preview.src=e.target.result;preview.style.display="block";placeholder.style.display="none";};
 reader.readAsDataURL(file);
});
</script>
</body>
</html>
