-- Graham Delight: per-product size and price options
-- Run this once in phpMyAdmin after selecting your Graham Delight database.
-- Existing products and their products.price values are preserved.

CREATE TABLE IF NOT EXISTS product_sizes (
    product_size_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    size_name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    INDEX idx_product_sizes_product_id (product_id),
    UNIQUE KEY uq_product_size_name (product_id, size_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Optional example for one product (replace 12 with the actual product_id):
-- INSERT INTO product_sizes (product_id, size_name, price)
-- VALUES (12, 'Small', 99.00), (12, 'Medium', 149.00), (12, 'Large', 199.00);
