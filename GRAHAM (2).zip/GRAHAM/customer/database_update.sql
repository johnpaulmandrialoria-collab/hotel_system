
-- Run this once in phpMyAdmin after selecting graham_delight_db.
-- Existing cart/order records will receive the default size "Medium".
ALTER TABLE cart
ADD COLUMN size ENUM('Small','Medium','Large') NOT NULL DEFAULT 'Medium' AFTER product_id;

ALTER TABLE order_items
ADD COLUMN size ENUM('Small','Medium','Large') NOT NULL DEFAULT 'Medium' AFTER product_id;
