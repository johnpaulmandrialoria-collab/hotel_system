<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$search = "";

$sql = "SELECT p.*, c.category_name, IFNULL(i.stock,0) AS stock
        FROM products p
        LEFT JOIN categories c ON p.category_id=c.category_id
        LEFT JOIN inventory i ON p.product_id=i.product_id
        WHERE p.status='Available'";

if(isset($_GET['search']) && $_GET['search']!=""){
    $search = trim($_GET['search']);
    $search_safe = $conn->real_escape_string($search);
    $sql .= " AND (p.product_name LIKE '%$search_safe%' OR c.category_name LIKE '%$search_safe%')";
}
$sql .= " ORDER BY p.product_id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Products | Graham Delight</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
body{background:#FFF8F0;font-family:Poppins,sans-serif}
.navbar{background:#6F4E37}.navbar-brand{color:white;font-weight:700}
.nav-link{color:white!important}.card{border:none;border-radius:15px;transition:.3s}
.card:hover{transform:translateY(-5px);box-shadow:0 10px 25px rgba(0,0,0,.15)}
.card img{height:230px;object-fit:cover}.price{font-size:22px;font-weight:bold;color:#D4AF37}
.btn-cart{background:#6F4E37;color:white}.btn-cart:hover{background:#55351f;color:white}
.size-option{min-width:90px}.unit-total{font-size:1.35rem;font-weight:700;color:#198754}
.quantity-control{max-width:170px}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
<div class="container">
<a class="navbar-brand" href="#">🍰 Graham Delight</a>
<div class="ms-auto">
<a href="cart.php" class="btn btn-warning"><i class="bi bi-cart-fill"></i> Cart</a>
<a href="dashboard.php" class="btn btn-light">Dashboard</a>
<a href="logout.php" class="btn btn-danger">Logout</a>
</div>
</div>
</nav>

<div class="container py-5">
<form method="GET">
<div class="row mb-4">
<div class="col-md-10">
<input type="text" name="search" class="form-control" placeholder="Search Products..." value="<?php echo htmlspecialchars($search); ?>">
</div>
<div class="col-md-2"><button class="btn btn-dark w-100">Search</button></div>
</div>
</form>

<div class="row">
<?php if($result && $result->num_rows > 0){ while($row = $result->fetch_assoc()){
$image = "../uploads/products/".$row['image'];
if(!file_exists($image) || empty($row['image'])) $image="../assets/images/image.png";
$sizeStmt = $conn->prepare("SELECT size_name, price FROM product_sizes WHERE product_id=? ORDER BY product_size_id ASC");
$sizeStmt->bind_param("i", $row['product_id']);
$sizeStmt->execute();
$sizeResult = $sizeStmt->get_result();
$productSizes = [];
while ($sizeRow = $sizeResult->fetch_assoc()) {
    if (in_array($sizeRow['size_name'], ['Small','Medium','Large'], true)) {
        $productSizes[$sizeRow['size_name']] = (float)$sizeRow['price'];
    }
}
$sizeStmt->close();
if (!$productSizes) {
    $productSizes = ['Small'=>(float)$row['price'], 'Medium'=>(float)$row['price'], 'Large'=>(float)$row['price']];
}
$displayPrice = min($productSizes);
$sizeJson = htmlspecialchars(json_encode($productSizes, JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP), ENT_QUOTES, 'UTF-8');
?>
<div class="col-lg-4 col-md-6 mb-4">
<div class="card h-100 shadow-sm">
<img src="<?php echo htmlspecialchars($image); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($row['product_name']); ?>">
<div class="card-body d-flex flex-column">
<h5><?php echo htmlspecialchars($row['product_name']); ?></h5>
<p class="text-muted"><?php echo htmlspecialchars($row['description']); ?></p>
<div class="mb-2"><span class="badge bg-secondary"><?php echo htmlspecialchars($row['category_name'] ?? ''); ?></span></div>
<div class="price mb-2">From ₱<?php echo number_format($displayPrice,2); ?></div>
<?php if((int)$row['stock']>0){ ?>
<span class="badge bg-success mb-3">In Stock (<?php echo (int)$row['stock']; ?>)</span>
<div class="mt-auto">
<button type="button" class="btn btn-cart w-100 open-unit-modal"
data-bs-toggle="modal" data-bs-target="#unitModal"
data-product-id="<?php echo (int)$row['product_id']; ?>"
data-product-name="<?php echo htmlspecialchars($row['product_name'],ENT_QUOTES); ?>"
data-product-sizes="<?php echo $sizeJson; ?>"
data-product-image="<?php echo htmlspecialchars($image,ENT_QUOTES); ?>"
data-stock="<?php echo (int)$row['stock']; ?>" data-action="add">
<i class="bi bi-cart-plus"></i> Add to Cart
</button>
<button type="button" class="btn btn-secondary w-100 mt-2 open-unit-modal"
data-bs-toggle="modal" data-bs-target="#unitModal"
data-product-id="<?php echo (int)$row['product_id']; ?>"
data-product-name="<?php echo htmlspecialchars($row['product_name'],ENT_QUOTES); ?>"
data-product-sizes="<?php echo $sizeJson; ?>"
data-product-image="<?php echo htmlspecialchars($image,ENT_QUOTES); ?>"
data-stock="<?php echo (int)$row['stock']; ?>" data-action="buy">
<i class="bi bi-bag-check"></i> Buy Now
</button>
</div>
<?php } else { ?>
<button class="btn btn-secondary w-100 mt-auto" disabled>Out of Stock</button>
<?php } ?>
</div>
</div>
</div>
<?php }} else { ?>
<div class="col-12"><div class="alert alert-warning">No Products Found.</div></div>
<?php } ?>
</div>
</div>

<!-- Product unit selection modal -->
<div class="modal fade" id="unitModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content border-0 rounded-4">
<form action="add-to-cart.php" method="POST" id="unitForm">
<div class="modal-header border-0">
<h5 class="modal-title fw-bold">Select Product Unit</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body pt-0">
<div class="d-flex gap-3 align-items-center mb-3">
<img id="unitImage" src="" alt="" style="width:105px;height:105px;object-fit:cover;border-radius:12px">
<div>
<div class="fw-semibold" id="unitName"></div>
<div class="text-success fw-bold fs-5">₱<span id="unitPriceText">0.00</span></div>
<small class="text-muted">Available stock: <span id="unitStock">0</span></small>
</div>
</div>
<input type="hidden" name="product_id" id="unitProductId">
<input type="hidden" name="action_type" id="unitAction" value="add">
<label class="form-label fw-semibold">Size</label>
<div class="d-flex flex-wrap gap-2 mb-3" id="unitSizeOptions"></div>
<label class="form-label fw-semibold">Quantity</label>
<div class="input-group quantity-control mb-3">
<button class="btn btn-outline-secondary" type="button" id="qtyMinus"><i class="bi bi-dash"></i></button>
<input class="form-control text-center" type="number" name="quantity" id="unitQuantity" value="1" min="1" max="1" required>
<button class="btn btn-outline-secondary" type="button" id="qtyPlus"><i class="bi bi-plus"></i></button>
</div>
<div class="d-flex justify-content-between align-items-center border-top pt-3">
<span class="fw-semibold">Total Price</span>
<span class="unit-total">₱<span id="unitTotal">0.00</span></span>
</div>
<small class="text-muted d-block mt-2">The price updates automatically when you select a size.</small>
</div>
<div class="modal-footer border-0 pt-0">
<button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-success flex-grow-1" id="unitSubmit">Add to Cart</button>
</div>
</form>
</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let selectedPrice = 0, selectedStock = 1, availableSizePrices = {};
const quantityInput = document.getElementById('unitQuantity');
const sizeOptions = document.getElementById('unitSizeOptions');
function updateUnitTotal(){
    const qty = Math.max(1, parseInt(quantityInput.value || 1, 10));
    quantityInput.value = qty;
    document.getElementById('unitTotal').textContent = (selectedPrice * qty).toFixed(2);
    document.getElementById('unitPriceText').textContent = selectedPrice.toFixed(2);
}
function renderSizeOptions(){
    sizeOptions.innerHTML = '';
    Object.entries(availableSizePrices).forEach(([size, price], index) => {
        const id = 'unitSize' + index;
        const input = document.createElement('input');
        input.className = 'btn-check'; input.type = 'radio'; input.name = 'size';
        input.id = id; input.value = size; input.checked = index === 0;
        const label = document.createElement('label');
        label.className = 'btn btn-outline-secondary size-option';
        label.htmlFor = id; label.textContent = size;
        sizeOptions.append(input, label);
        input.addEventListener('change', () => { selectedPrice = Number(availableSizePrices[size]); updateUnitTotal(); });
    });
    selectedPrice = Number(availableSizePrices[Object.keys(availableSizePrices)[0]] || 0);
}
document.querySelectorAll('.open-unit-modal').forEach(button => {
    button.addEventListener('click', function(){
        selectedStock = parseInt(this.dataset.stock, 10);
        availableSizePrices = JSON.parse(this.dataset.productSizes || '{}');
        document.getElementById('unitProductId').value = this.dataset.productId;
        document.getElementById('unitName').textContent = this.dataset.productName;
        document.getElementById('unitImage').src = this.dataset.productImage;
        document.getElementById('unitStock').textContent = selectedStock;
        document.getElementById('unitAction').value = this.dataset.action;
        document.getElementById('unitSubmit').textContent = this.dataset.action === 'buy' ? 'Buy Now' : 'Add to Cart';
        quantityInput.value = 1; quantityInput.max = selectedStock;
        renderSizeOptions(); updateUnitTotal();
    });
});
document.getElementById('qtyMinus').addEventListener('click', () => {
    quantityInput.value = Math.max(1, parseInt(quantityInput.value || 1, 10)-1); updateUnitTotal();
});
document.getElementById('qtyPlus').addEventListener('click', () => {
    quantityInput.value = Math.min(selectedStock, parseInt(quantityInput.value || 1, 10)+1); updateUnitTotal();
});
quantityInput.addEventListener('input', () => {
    if (parseInt(quantityInput.value || 1, 10) > selectedStock) quantityInput.value = selectedStock;
    updateUnitTotal();
});
document.getElementById('unitForm').addEventListener('submit', function(e){
    const qty = parseInt(quantityInput.value, 10);
    if (!qty || qty < 1 || qty > selectedStock || !document.querySelector('input[name="size"]:checked')) {
        e.preventDefault(); alert('Please select a valid size and quantity within the available stock.');
    }
});
</script>
</body>
</html>
