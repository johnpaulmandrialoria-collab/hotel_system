<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = (int) $_SESSION['user_id'];
$cart_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($cart_id <= 0) {
    $_SESSION['cart_message'] = "Invalid cart item.";
    header("Location: cart.php");
    exit();
}

/*
 * Delete only the selected cart row belonging to the logged-in customer.
 * This prevents one customer from deleting another customer's cart item.
 */
$stmt = $conn->prepare("DELETE FROM cart WHERE cart_id = ? AND user_id = ?");
if (!$stmt) {
    $_SESSION['cart_message'] = "Unable to remove this item. Please try again.";
    header("Location: cart.php");
    exit();
}

$stmt->bind_param("ii", $cart_id, $user_id);
if ($stmt->execute() && $stmt->affected_rows > 0) {
    $_SESSION['cart_message'] = "Product removed from your cart.";
} else {
    $_SESSION['cart_message'] = "The cart item was not found or was already removed.";
}

$stmt->close();
header("Location: cart.php");
exit();
?>
