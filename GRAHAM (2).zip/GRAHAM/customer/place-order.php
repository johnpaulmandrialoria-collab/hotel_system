<?php
session_start();
include '../config/database.php';
if (!isset($_SESSION['user_id'])) { header("Location: ../login.php"); exit(); }
$user_id = (int)$_SESSION['user_id'];
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header("Location: product.php"); exit(); }

$payment_method = $_POST['payment_method'] ?? '';
$checkout_mode = $_POST['checkout_mode'] ?? 'cart';
if (!in_array($payment_method,['Cash on Delivery','GCash'],true) ||
    !in_array($checkout_mode,['cart','direct'],true)) die("Invalid checkout request.");

$conn->begin_transaction();
try {
    $items = [];
    if ($checkout_mode === 'direct') {
        if (empty($_SESSION['direct_buy'])) throw new Exception("Your Buy Now selection has expired.");
        $d = $_SESSION['direct_buy']; $pid=(int)$d['product_id']; $qty=(int)$d['quantity']; $size=$d['size'];
        $stmt = $conn->prepare("SELECT p.product_id,COALESCE(ps.price,p.price) AS unit_price,IFNULL(i.stock,0) AS stock
            FROM products p LEFT JOIN inventory i ON i.product_id=p.product_id
            LEFT JOIN product_sizes ps ON ps.product_id=p.product_id AND ps.size_name=?
            WHERE p.product_id=? AND p.status='Available' FOR UPDATE");
        $stmt->bind_param("si",$size,$pid); $stmt->execute(); $row=$stmt->get_result()->fetch_assoc();
        if (!$row || $qty<1 || $qty>(int)$row['stock'] || !in_array($size,['Small','Medium','Large'],true))
            throw new Exception("Product stock or selection is no longer valid.");
        $items[]=['product_id'=>$pid,'quantity'=>$qty,'size'=>$size,'price'=>(float)$row['unit_price']];
    } else {
        $stmt = $conn->prepare("SELECT c.product_id,c.quantity,c.size,COALESCE(ps.price,p.price) AS unit_price,
            IFNULL(i.stock,0) AS stock,p.status
            FROM cart c INNER JOIN products p ON p.product_id=c.product_id
            LEFT JOIN inventory i ON i.product_id=p.product_id
            LEFT JOIN product_sizes ps ON ps.product_id=p.product_id AND ps.size_name=c.size
            WHERE c.user_id=? FOR UPDATE");
        $stmt->bind_param("i",$user_id); $stmt->execute(); $res=$stmt->get_result();
        while ($r=$res->fetch_assoc()) {
            if ($r['status']!=='Available' || (int)$r['quantity']<1 || (int)$r['quantity']>(int)$r['stock'])
                throw new Exception("Insufficient stock or unavailable product in your cart.");
            $items[]=['product_id'=>(int)$r['product_id'],'quantity'=>(int)$r['quantity'],
                      'size'=>$r['size'],'price'=>(float)$r['unit_price']];
        }
        if (!$items) throw new Exception("Your cart is empty.");
    }

    $total=0; foreach ($items as $item) $total += $item['price']*$item['quantity'];
    $order = $conn->prepare("INSERT INTO orders(user_id,total_amount,payment_method,status) VALUES(?,?,?,'Pending')");
    $order->bind_param("ids",$user_id,$total,$payment_method); $order->execute(); $order_id=$conn->insert_id;
    $insert = $conn->prepare("INSERT INTO order_items(order_id,product_id,size,quantity,price) VALUES(?,?,?,?,?)");
    $stock = $conn->prepare("UPDATE inventory SET stock=stock-?,last_updated=CURRENT_TIMESTAMP WHERE product_id=? AND stock>=?");
    foreach ($items as $item) {
        $pid=$item['product_id']; $qty=$item['quantity']; $size=$item['size']; $price=$item['price'];
        $insert->bind_param("iisid",$order_id,$pid,$size,$qty,$price); $insert->execute();
        $stock->bind_param("iii",$qty,$pid,$qty); $stock->execute();
        if ($stock->affected_rows!==1) throw new Exception("Stock changed while placing your order. Please try again.");
    }
    if ($checkout_mode==='cart') {
        $del=$conn->prepare("DELETE FROM cart WHERE user_id=?"); $del->bind_param("i",$user_id); $del->execute();
    } else unset($_SESSION['direct_buy']);
    $conn->commit(); header("Location: order-success.php"); exit();
} catch (Throwable $e) {
    $conn->rollback(); die("Order Failed: ".htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8'));
}
?>
