<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
$user_id = (int)$_SESSION['user_id'];

// Update quantities from the cart page.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    if (isset($_POST['quantities']) && is_array($_POST['quantities'])) {
        foreach ($_POST['quantities'] as $cart_id => $qty) {
            $cart_id = (int)$cart_id;
            $qty = (int)$qty;
            if ($cart_id < 1 || $qty < 1) continue;

            $stockStmt = $conn->prepare("
                SELECT IFNULL(i.stock,0) AS stock
                FROM cart c
                LEFT JOIN inventory i ON i.product_id=c.product_id
                WHERE c.cart_id=? AND c.user_id=?
            ");
            $stockStmt->bind_param("ii", $cart_id, $user_id);
            $stockStmt->execute();
            $stockRow = $stockStmt->get_result()->fetch_assoc();
            if ($stockRow) {
                $qty = min($qty, (int)$stockRow['stock']);
                $update = $conn->prepare("UPDATE cart SET quantity=? WHERE cart_id=? AND user_id=?");
                $update->bind_param("iii", $qty, $cart_id, $user_id);
                $update->execute();
            }
        }
    }
    header("Location: cart.php");
    exit();
}

$sql = "
SELECT c.cart_id, c.quantity, c.size, p.product_id, p.product_name, COALESCE(ps.price,p.price) AS unit_price, p.image,
       IFNULL(i.stock,0) AS stock
FROM cart c
INNER JOIN products p ON c.product_id=p.product_id
LEFT JOIN inventory i ON p.product_id=i.product_id
LEFT JOIN product_sizes ps ON ps.product_id=p.product_id AND ps.size_name=c.size
WHERE c.user_id=?
ORDER BY c.cart_id DESC
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$grandTotal = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Shopping Cart</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body{background:#FFF8F0;font-family:Poppins,sans-serif}.navbar{background:#6F4E37}
.navbar-brand{color:white;font-weight:bold}.card{border:none;border-radius:15px}
.product-img{width:90px;height:90px;object-fit:cover;border-radius:10px}
.total-box{background:#fff;padding:20px;border-radius:15px;box-shadow:0 0 15px rgba(0,0,0,.08)}
.qty-input{max-width:85px}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg"><div class="container">
<a class="navbar-brand">🍰 Graham Delight</a>
<div><a href="product.php" class="btn btn-warning">Continue Shopping</a>
<a href="logout.php" class="btn btn-danger">Logout</a></div>
</div></nav>

<div class="container py-5">
<h2 class="mb-4">🛒 My Shopping Cart</h2>
<?php if($result->num_rows > 0){ ?>
<div class="card shadow"><div class="card-body">
<form method="POST">
<div class="table-responsive">
<table class="table align-middle">
<thead class="table-dark"><tr>
<th>Image</th><th>Product</th><th>Size</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th>Action</th>
</tr></thead>
<tbody>
<?php while($row = $result->fetch_assoc()){
$subtotal = (float)$row['unit_price'] * (int)$row['quantity'];
$grandTotal += $subtotal;
$image = "../uploads/products/".$row['image'];
if(empty($row['image']) || !file_exists($image)) $image = "../assets/images/image.png";
?>
<tr>
<td><img src="<?php echo htmlspecialchars($image); ?>" class="product-img" alt=""></td>
<td><strong><?php echo htmlspecialchars($row['product_name']); ?></strong><br>
<small class="text-muted">Stock: <?php echo (int)$row['stock']; ?></small></td>
<td><?php echo htmlspecialchars($row['size']); ?></td>
<td>₱<?php echo number_format((float)$row['unit_price'],2); ?></td>
<td><input class="form-control qty-input" type="number" name="quantities[<?php echo (int)$row['cart_id']; ?>]"
value="<?php echo (int)$row['quantity']; ?>" min="1" max="<?php echo (int)$row['stock']; ?>" required></td>
<td><strong>₱<?php echo number_format($subtotal,2); ?></strong></td>
<td><a href="remove-cart.php?id=<?php echo (int)$row['cart_id']; ?>" class="btn btn-danger btn-sm"
onclick="return confirm('Remove this item?')"><i class="bi bi-trash"></i></a></td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
<button type="submit" name="update_cart" value="1" class="btn btn-outline-primary">
<i class="bi bi-arrow-repeat"></i> Update Cart
</button>
<a href="product.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Continue Shopping</a>
<div class="total-box text-end">
<h4>Grand Total</h4>
<h2 class="text-success">₱<?php echo number_format($grandTotal,2); ?></h2>
<a href="checkout.php" class="btn btn-success btn-lg mt-2">
<i class="bi bi-credit-card"></i> Proceed to Checkout</a>
</div>
</div>
</form>
</div></div>
<?php } else { ?>
<div class="card shadow"><div class="card-body text-center p-5">
<i class="bi bi-cart-x" style="font-size:80px;color:#999;"></i>
<h3 class="mt-3">Your cart is empty</h3>
<p class="text-muted">Looks like you haven't added any products yet.</p>
<a href="product.php" class="btn btn-primary"><i class="bi bi-bag"></i> Browse Products</a>
</div></div>
<?php } ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
