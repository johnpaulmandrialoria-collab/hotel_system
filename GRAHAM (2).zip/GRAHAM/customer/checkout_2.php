<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
$user_id = (int)$_SESSION['user_id'];
$checkoutMode = "direct";
$items = [];
$grandTotal = 0;

if ($checkoutMode === 'direct') {
    if (empty($_SESSION['direct_buy'])) {
        header("Location: product.php");
        exit();
    }
    $direct = $_SESSION['direct_buy'];
    $product_id = (int)$direct['product_id'];
    $quantity = (int)$direct['quantity'];
    $size = $direct['size'];

    $stmt = $conn->prepare("
        SELECT p.product_id,p.product_name,COALESCE(ps.price,p.price) AS unit_price,p.image,IFNULL(i.stock,0) AS stock
        FROM products p
        LEFT JOIN inventory i ON i.product_id=p.product_id
        LEFT JOIN product_sizes ps ON ps.product_id=p.product_id AND ps.size_name=?
        WHERE p.product_id=? AND p.status='Available'
    ");
    $stmt->bind_param("si", $size, $product_id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();

    if (!$product || $quantity < 1 || $quantity > (int)$product['stock'] ||
        !in_array($size,['Small','Medium','Large'],true)) {
        unset($_SESSION['direct_buy']);
        die("The selected product or quantity is no longer available. Please select it again.");
    }
    $product['quantity'] = $quantity;
    $product['size'] = $size;
    $items[] = $product;
} else {
    $stmt = $conn->prepare("
        SELECT c.cart_id,c.quantity,c.size,p.product_id,p.product_name,COALESCE(ps.price,p.price) AS unit_price,p.image,
               IFNULL(i.stock,0) AS stock
        FROM cart c
        INNER JOIN products p ON c.product_id=p.product_id
        LEFT JOIN inventory i ON i.product_id=p.product_id
        LEFT JOIN product_sizes ps ON ps.product_id=p.product_id AND ps.size_name=c.size
        WHERE c.user_id=?
        ORDER BY c.cart_id DESC
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $items[] = $row;
}
if (!$items) {
    header("Location: cart.php");
    exit();
}
foreach ($items as $item) $grandTotal += (float)$item['unit_price'] * (int)$item['quantity'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Checkout | Graham Delight</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body{background:#FFF8F0;font-family:Poppins,sans-serif}.card{border:none;border-radius:15px}
.product-img{width:55px;height:55px;object-fit:cover;border-radius:8px}
</style>
</head>
<body>
<div class="container py-5">
<h2 class="mb-4">Checkout</h2>
<form action="place-order.php" method="POST">
<input type="hidden" name="checkout_mode" value="<?php echo htmlspecialchars($checkoutMode); ?>">
<div class="row">
<div class="col-lg-8">
<div class="card shadow"><div class="card-body">
<h4 class="mb-3">Order Summary</h4>
<div class="table-responsive">
<table class="table align-middle">
<thead><tr><th>Product</th><th>Size</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr></thead>
<tbody>
<?php foreach($items as $row){
$subtotal = (float)$row['unit_price'] * (int)$row['quantity'];
$image = "../uploads/products/".$row['image'];
if(empty($row['image']) || !file_exists($image)) $image="../assets/images/image.png";
?>
<tr>
<td><div class="d-flex align-items-center gap-2"><img src="<?php echo htmlspecialchars($image); ?>" class="product-img" alt="">
<span><?php echo htmlspecialchars($row['product_name']); ?></span></div></td>
<td><?php echo htmlspecialchars($row['size']); ?></td>
<td><?php echo (int)$row['quantity']; ?></td>
<td>₱<?php echo number_format((float)$row['unit_price'],2); ?></td>
<td>₱<?php echo number_format($subtotal,2); ?></td>
</tr>
<?php } ?>
</tbody></table></div>
<hr><div class="text-end"><h3>Total: <strong class="text-success">₱<?php echo number_format($grandTotal,2); ?></strong></h3></div>
</div></div>
</div>
<div class="col-lg-4">
<div class="card shadow"><div class="card-body">
<h4 class="mb-3">Payment Method</h4>
<div class="form-check"><input class="form-check-input" type="radio" name="payment_method" value="Cash on Delivery" checked required>
<label class="form-check-label">Cash on Delivery</label></div>
<div class="form-check mt-2"><input class="form-check-input" type="radio" name="payment_method" value="GCash">
<label class="form-check-label">GCash</label></div>
<hr>
<button type="submit" class="btn btn-success w-100"><i class="bi bi-check-circle"></i> Place Order</button>
<a href="<?php echo $checkoutMode === 'direct' ? 'product.php' : 'cart.php'; ?>" class="btn btn-secondary w-100 mt-2">
<?php echo $checkoutMode === 'direct' ? 'Back to Products' : 'Back to Cart'; ?></a>
</div></div>
</div>
</div>
</form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
