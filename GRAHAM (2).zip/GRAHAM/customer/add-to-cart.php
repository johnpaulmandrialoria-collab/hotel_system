<?php
session_start();
include '../config/database.php';
if (!isset($_SESSION['user_id'])) { header("Location: ../login.php"); exit(); }
$user_id = (int)$_SESSION['user_id'];
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header("Location: product.php"); exit(); }

$product_id = (int)($_POST['product_id'] ?? 0);
$quantity = (int)($_POST['quantity'] ?? 0);
$size = trim($_POST['size'] ?? '');
$action_type = $_POST['action_type'] ?? 'add';
if ($product_id < 1 || $quantity < 1 || !in_array($size, ['Small','Medium','Large'], true) ||
    !in_array($action_type, ['add','buy'], true)) die("Invalid product selection.");

$conn->begin_transaction();
try {
    $stmt = $conn->prepare("SELECT p.product_id, IFNULL(i.stock,0) AS stock,
        ps.price AS size_price, p.price AS base_price
        FROM products p LEFT JOIN inventory i ON i.product_id=p.product_id
        LEFT JOIN product_sizes ps ON ps.product_id=p.product_id AND ps.size_name=?
        WHERE p.product_id=? AND p.status='Available' FOR UPDATE");
    $stmt->bind_param("si", $size, $product_id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    if (!$product) throw new Exception("Product not found or unavailable.");
    $countStmt = $conn->prepare("SELECT COUNT(*) AS n FROM product_sizes WHERE product_id=?");
    $countStmt->bind_param("i", $product_id); $countStmt->execute();
    $hasSizes = (int)$countStmt->get_result()->fetch_assoc()['n'] > 0;
    if ($hasSizes && $product['size_price'] === null) throw new Exception("That size is not available.");
    if ($quantity > (int)$product['stock']) throw new Exception("The selected quantity exceeds available stock.");

    if ($action_type === 'buy') {
        $conn->commit();
        $_SESSION['direct_buy'] = ['product_id'=>$product_id,'quantity'=>$quantity,'size'=>$size];
        header("Location: checkout_2.php"); exit();
    }
    $check = $conn->prepare("SELECT cart_id,quantity FROM cart WHERE user_id=? AND product_id=? AND size=? LIMIT 1");
    $check->bind_param("iis",$user_id,$product_id,$size); $check->execute();
    $existing = $check->get_result()->fetch_assoc();
    if ($existing) {
        $newQty = (int)$existing['quantity'] + $quantity;
        if ($newQty > (int)$product['stock']) throw new Exception("Adding this quantity would exceed available stock.");
        $upd = $conn->prepare("UPDATE cart SET quantity=? WHERE cart_id=? AND user_id=?");
        $upd->bind_param("iii",$newQty,$existing['cart_id'],$user_id); $upd->execute();
    } else {
        $ins = $conn->prepare("INSERT INTO cart(user_id,product_id,size,quantity) VALUES(?,?,?,?)");
        $ins->bind_param("iisi",$user_id,$product_id,$size,$quantity); $ins->execute();
    }
    $conn->commit(); header("Location: cart.php"); exit();
} catch (Throwable $e) {
    $conn->rollback(); die(htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8'));
}
?>