<?php
// Database connection settings. Update these values if your MySQL setup differs.
$host = 'localhost';
$dbname = 'student_registration';
$username = 'root';
$password = '';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}

$conn->set_charset('utf8mb4');
?>
