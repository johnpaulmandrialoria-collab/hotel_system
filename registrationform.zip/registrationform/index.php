<?php
require_once 'db.php';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname'] ?? '');
    $birthday = $_POST['birthday'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $course = $_POST['course'] ?? '';
    $address = trim($_POST['address'] ?? '');

    if (!$fullname || !$birthday || !$gender || !$email || !$password || !$course || !$address) {
        $message = 'Please complete all required fields.';
        $messageType = 'danger';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter a valid email address.';
        $messageType = 'danger';
    } elseif (strlen($password) < 8) {
        $message = 'Password must contain at least 8 characters.';
        $messageType = 'danger';
    } else {
        $check = $conn->prepare('SELECT id FROM students WHERE email = ?');
        $check->bind_param('s', $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = 'That email is already registered.';
            $messageType = 'warning';
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare('INSERT INTO students (fullname, email, password, gender, course, address, birthday) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('sssssss', $fullname, $email, $hashedPassword, $gender, $course, $address, $birthday);

            if ($stmt->execute()) {
                $message = 'Registration successful!.';
                $messageType = 'success';
            } else {
                $message = 'Unable to save the registration. Please try again.';
                $messageType = 'danger';
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .radio-card {
            display: block;
            margin-bottom: 10px;
        }
        
            :root {
                --primary: #4f46e5;
                --primary-dark: #3730a3;
                --secondary: #06b6d4;
                --bg: #eef2ff;
                --surface: #ffffff;
                --text: #172033;
                --muted: #64748b;
                --border: #dbe3ef;
                --focus: rgba(79, 70, 229, 0.14);
            }

            * {
                box-sizing: border-box;
            }

            html {
                min-height: 100%;
            }

            body {
                min-height: 100vh;
                margin: 0;
                padding: 32px 16px;
                display: flex;
                justify-content: center;
                align-items: center;
                color: var(--text);
                font-family: Inter, "Segoe UI", Arial, sans-serif;
                background:
                    radial-gradient(circle at 10% 10%, rgba(99, 102, 241, .22), transparent 32%),
                    radial-gradient(circle at 90% 90%, rgba(6, 182, 212, .18), transparent 32%),
                    linear-gradient(135deg, #eef2ff 0%, #f8fafc 50%, #ecfeff 100%);
            }

            /* Keeps the whole form centered vertically and horizontally */
            .registration-wrapper {
                width: 100%;
                max-width: 920px;
                margin: 0 auto;
                padding: 0;
            }

            .registration-wrapper > .row {
                width: 100%;
                margin: 0;
                justify-content: center;
            }

            .registration-wrapper [class*="col-"] {
                width: 100%;
                max-width: 820px;
                padding: 0;
            }

            /* Main registration card */
            .card {
                width: 100%;
                margin: 0 auto;
                overflow: hidden;
                border: 0 !important;
                border-radius: 24px !important;
                background: var(--surface) !important;
                box-shadow:
                    0 30px 80px rgba(15, 23, 42, .18),
                    0 8px 25px rgba(79, 70, 229, .10) !important;
                animation: cardEnter .65s ease-out both;
            }

            /* Header */
            .card-header-custom {
                position: relative;
                padding: 34px 40px;
                overflow: hidden;
                color: #fff;
                background: linear-gradient(135deg, var(--primary) 0%, #6366f1 50%, var(--secondary) 100%);
            }

            .card-header-custom::before,
            .card-header-custom::after {
                content: "";
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, .12);
                pointer-events: none;
            }

            .card-header-custom::before {
                width: 180px;
                height: 180px;
                top: -90px;
                right: -40px;
            }

            .card-header-custom::after {
                width: 100px;
                height: 100px;
                bottom: -55px;
                left: 30%;
            }

            .card-header-custom h2,
            .card-header-custom p {
                position: relative;
                z-index: 1;
            }

            .card-header-custom h2 {
                margin: 0 0 8px;
                font-size: 2rem;
                font-weight: 800;
                letter-spacing: -.6px;
            }

            .card-header-custom p {
                margin: 0;
                opacity: .92;
                font-size: 1rem;
            }

            .card-body {
                padding: 38px 40px !important;
            }

            /* Success/error messages */
            .alert {
                border: 0;
                border-radius: 14px;
                margin-bottom: 24px;
                box-shadow: 0 5px 16px rgba(15, 23, 42, .06);
            }

            /* Live preview */
            #previewBox {
                display: none;
                margin-bottom: 24px;
                padding: 15px 18px;
                border: 1px solid #c7d2fe;
                border-left: 5px solid var(--primary);
                border-radius: 14px;
                background: linear-gradient(90deg, #eef2ff, #f8fafc);
                animation: fadeSlide .3s ease;
            }

            #previewBox strong {
                color: var(--primary-dark);
            }

            /* Section headings */
            .section-title {
                display: flex;
                align-items: center;
                gap: 11px;
                margin: 30px 0 18px;
                padding-bottom: 10px;
                border-bottom: 1px solid #e8edf5;
                font-size: 1.08rem;
                font-weight: 750;
                color: #1e293b;
            }

            .section-title:first-child {
                margin-top: 0;
            }

            .section-number {
                flex: 0 0 32px;
                width: 32px;
                height: 32px;
                display: grid;
                place-items: center;
                border-radius: 50%;
                color: #fff;
                font-size: .86rem;
                font-weight: 800;
                background: linear-gradient(135deg, var(--primary), var(--secondary));
                box-shadow: 0 5px 12px rgba(79, 70, 229, .22);
            }

            .form-label {
                display: block;
                margin-bottom: 8px;
                color: #334155;
                font-weight: 700;
            }

            /* Inputs */
            .form-control,
            .form-select {
                min-height: 48px;
                border: 1px solid var(--border) !important;
                border-radius: 12px !important;
                padding: 11px 14px;
                color: var(--text);
                background-color: #fff;
                transition: border-color .2s ease, box-shadow .2s ease, transform .2s ease;
            }

            textarea.form-control {
                min-height: 105px;
                resize: vertical;
            }

            .form-control::placeholder {
                color: #94a3b8;
            }

            .form-control:hover,
            .form-select:hover {
                border-color: #a5b4fc !important;
            }

            .form-control:focus,
            .form-select:focus {
                border-color: var(--primary) !important;
                box-shadow: 0 0 0 4px var(--focus) !important;
                outline: none;
                transform: translateY(-1px);
            }

            .input-group .form-control {
                border-radius: 12px 0 0 12px !important;
            }

            .input-group .btn {
                min-width: 78px;
                border-radius: 0 12px 12px 0;
            }

            /* Gender choices */
            .radio-card {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                min-height: 44px;
                margin: 0 6px 7px 0;
                padding: 8px 13px;
                border: 1px solid var(--border);
                border-radius: 11px;
                color: #475569;
                cursor: pointer;
                transition: .2s ease;
            }

            .radio-card:hover {
                border-color: #a5b4fc;
                background: #f8f7ff;
                transform: translateY(-2px);
            }

            .radio-card:has(input:checked) {
                border-color: var(--primary);
                color: var(--primary-dark);
                background: #eef2ff;
                box-shadow: 0 4px 12px rgba(79, 70, 229, .10);
            }

            .form-check-input {
                cursor: pointer;
            }

            .form-check-input:checked {
                background-color: var(--primary);
                border-color: var(--primary);
            }

            .form-check-input:focus {
                box-shadow: 0 0 0 4px var(--focus);
            }

            /* Password strength */
            .password-strength {
                height: 7px;
                margin-top: 10px;
                overflow: hidden;
                border-radius: 999px;
                background: #e2e8f0;
            }

            .password-strength span {
                display: block;
                width: 0;
                height: 100%;
                border-radius: inherit;
                background: linear-gradient(90deg, var(--primary), var(--secondary));
                transition: width .3s ease;
            }

            .strength-text {
                margin-top: 6px;
                color: var(--muted);
                font-size: .82rem;
            }

            /* Buttons */
            .btn {
                min-height: 48px;
                border-radius: 12px !important;
                padding: 11px 18px;
                font-weight: 700;
                transition: transform .2s ease, box-shadow .2s ease, background .2s ease;
            }

            .btn-primary {
                border: 0 !important;
                background: linear-gradient(135deg, var(--primary), #6366f1) !important;
                box-shadow: 0 8px 18px rgba(79, 70, 229, .20);
            }

            .btn-primary:hover {
                transform: translateY(-2px);
                box-shadow: 0 12px 24px rgba(79, 70, 229, .28);
            }

            .btn-primary:active,
            .btn-secondary:active {
                transform: translateY(0);
            }

            .btn-secondary:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 18px rgba(15, 23, 42, .12);
            }

            /* Validation */
            .was-validated .form-control:invalid,
            .was-validated .form-select:invalid {
                border-color: #ef4444 !important;
            }

            .was-validated .form-control:valid,
            .was-validated .form-select:valid {
                border-color: #22c55e !important;
            }

            /* Animations */
            @keyframes cardEnter {
                from {
                    opacity: 0;
                    transform: translateY(25px) scale(.98);
                }
                to {
                    opacity: 1;
                    transform: translateY(0) scale(1);
                }
            }

            @keyframes fadeSlide {
                from {
                    opacity: 0;
                    transform: translateY(-5px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            /* Tablet */
            @media (max-width: 768px) {
                body {
                    align-items: flex-start;
                    padding: 20px 12px;
                }

                .registration-wrapper {
                    max-width: 680px;
                }

                .card-header-custom,
                .card-body {
                    padding: 28px !important;
                }
            }

            /* Mobile */
            @media (max-width: 576px) {
                body {
                    padding: 10px;
                }

                .card {
                    border-radius: 18px !important;
                }

                .card-header-custom,
                .card-body {
                    padding: 24px 20px !important;
                }

                .card-header-custom h2 {
                    font-size: 1.6rem;
                }

                .section-title {
                    margin-top: 25px;
                }

                .d-flex.gap-2 {
                    flex-direction: column;
                }

                .d-flex.gap-2 .btn {
                    width: 100%;
                }
            }

    </style>
</head>
<body>
<div class="container registration-wrapper">
    <div class="row justify-content-center">
        <div class="col-lg-8 col-xl-7">
            <div class="card">
                <div class="card-header-custom">
                    <h2>User Registration</h2>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-<?= htmlspecialchars($messageType) ?> alert-dismissible fade show" role="alert">
                            <?= htmlspecialchars($message) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div id="previewBox">
                        <strong>Live Preview:</strong> <span id="previewName">Your name</span>
                    </div>

                    <form method="POST" id="registrationForm" novalidate>
                        <div class="section-title"><span class="section-number">1</span> Personal Information</div>
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Full Name</label>
                            <input type="text" name="fullname" class="form-control" id="fullname" placeholder="Enter your full name" required>
                            <div class="invalid-feedback">Please enter your full name.</div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="birthday" class="form-label">Birthday</label>
                                <input type="date" name="birthday" class="form-control" id="birthday" required>
                                <div class="invalid-feedback">Please select your birthday.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label d-block">Gender</label>
                                <label class="radio-card"><input class="form-check-input" type="radio" name="gender" value="Male" required> Male</label>
                                <label class="radio-card"><input class="form-check-input" type="radio" name="gender" value="Female"> Female</label>
                                <label class="radio-card"><input class="form-check-input" type="radio" name="gender" value="Other"> Other</label>
                            </div>
                        </div>

                        <div class="section-title"><span class="section-number">2</span> Account Information</div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" id="email" placeholder="example@email.com" required>
                            <div class="invalid-feedback">Please enter a valid email.</div>
                        </div>
                        <div class="mb-2">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <input type="password" name="password" class="form-control" id="password" placeholder="At least 8 characters" minlength="8" required>
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword">Show</button>
                            </div>
                        </div>
                        <div class="password-strength"><span id="strengthBar"></span></div>
                        <div class="strength-text" id="strengthText">Password strength: —</div>

                        <div class="section-title"><span class="section-number">3</span> School Information</div>
                        <div class="mb-3">
                            <label for="course" class="form-label">Course</label>
                            <select name="course" class="form-select" id="course" required>
                                <option value="" selected disabled>Select your course</option>
                                <option>BS Information Technology</option>
                                <option>BS Computer Science</option>
                                <option>BS Information Systems</option>
                                <option>BS Business Administration</option>
                                <option>Other</option>
                            </select>
                            <div class="invalid-feedback">Please select a course.</div>
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea name="address" class="form-control" id="address" rows="3" placeholder="Enter your complete address" required></textarea>
                            <div class="invalid-feedback">Please enter your address.</div>
                        </div>

                        <div class="form-check mb-4 mt-4">
                            <input class="form-check-input" type="checkbox" id="terms" required>
                            <label class="form-check-label" for="terms">I agree to the Terms and Conditions.</label>
                            <div class="invalid-feedback">You must agree before submitting.</div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-fill">Register Student</button>
                            <button type="reset" class="btn btn-secondary flex-fill">Reset</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const form = document.getElementById('registrationForm');
const nameInput = document.getElementById('fullname');
const previewBox = document.getElementById('previewBox');
const previewName = document.getElementById('previewName');
const password = document.getElementById('password');
const strengthBar = document.getElementById('strengthBar');
const strengthText = document.getElementById('strengthText');

nameInput.addEventListener('input', () => {
    const value = nameInput.value.trim();
    previewBox.style.display = value ? 'block' : 'none';
    previewName.textContent = value || 'Your name';
});

document.getElementById('togglePassword').addEventListener('click', function () {
    const visible = password.type === 'text';
    password.type = visible ? 'password' : 'text';
    this.textContent = visible ? 'Show' : 'Hide';
});

password.addEventListener('input', () => {
    const value = password.value;
    let score = 0;
    if (value.length >= 8) score++;
    if (/[A-Z]/.test(value)) score++;
    if (/[0-9]/.test(value)) score++;
    if (/[^A-Za-z0-9]/.test(value)) score++;
    const widths = ['0%', '25%', '50%', '75%', '100%'];
    const labels = ['—', 'Weak', 'Fair', 'Good', 'Strong'];
    strengthBar.style.width = widths[score];
    strengthText.textContent = 'Password strength: ' + labels[score];
});

form.addEventListener('submit', event => {
    if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
    }
    form.classList.add('was-validated');
});
</script>
</body>
</html>